import React from 'react';
import { MapPin, Clock, Briefcase } from 'lucide-react';

interface Job {
  id: number;
  title: string;
  company: string;
  location: string;
  type: string;
  salary: string;
  posted: string;
}

interface JobCardProps {
  job: Job;
}

const JobCard: React.FC<JobCardProps> = ({ job }) => {
  return (
    <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition duration-300 transform hover:-translate-y-1 border-r-4 border-gold-500">
      <div className="mb-4">
        <h3 className="text-xl font-bold text-navy-900 mb-2">{job.title}</h3>
        <p className="text-gray-600 font-medium">{job.company}</p>
      </div>
      
      <div className="space-y-2 mb-5">
        <div className="flex items-center text-gray-600">
          <MapPin className="h-4 w-4 text-gray-400 mr-2" />
          {job.location}
        </div>
        <div className="flex items-center text-gray-600">
          <Briefcase className="h-4 w-4 text-gray-400 mr-2" />
          {job.type}
        </div>
        <div className="flex items-center text-gray-600">
          <Clock className="h-4 w-4 text-gray-400 mr-2" />
          {job.posted}
        </div>
      </div>
      
      <div className="flex items-center justify-between pt-4 border-t border-gray-100">
        <span className="text-gold-600 font-bold">{job.salary}</span>
        <button className="bg-navy-800 text-white px-4 py-2 rounded-lg hover:bg-navy-700 transition">
          التفاصيل
        </button>
      </div>
    </div>
  );
};

export default JobCard;