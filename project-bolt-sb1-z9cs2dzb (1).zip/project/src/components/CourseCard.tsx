import React from 'react';
import { Star } from 'lucide-react';

interface Course {
  id: number;
  title: string;
  instructor: string;
  image: string;
  price: number;
  duration: string;
  level: string;
  rating: number;
}

interface CourseCardProps {
  course: Course;
}

const CourseCard: React.FC<CourseCardProps> = ({ course }) => {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition duration-300 transform hover:-translate-y-1 group">
      <div className="relative overflow-hidden h-48">
        <img 
          src={course.image} 
          alt={course.title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-3 right-3 bg-navy-900 text-white px-3 py-1 rounded-full text-sm font-medium">
          {course.level}
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold mb-2 text-navy-900 line-clamp-2">{course.title}</h3>
        <p className="text-gray-500 mb-3">{course.instructor}</p>
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <Star className="h-4 w-4 text-amber-400 fill-current" />
            <span className="ml-1 text-gray-700">{course.rating.toFixed(1)}</span>
          </div>
          <span className="text-gray-600 text-sm">{course.duration}</span>
        </div>
        <div className="flex justify-between items-center pt-4 border-t border-gray-100">
          <span className="text-gold-600 font-bold">{course.price} ريال</span>
          <button className="bg-navy-800 text-white px-4 py-2 rounded-lg hover:bg-navy-700 transition">
            التفاصيل
          </button>
        </div>
      </div>
    </div>
  );
};

export default CourseCard;