import React from 'react';
import { Link } from 'react-router-dom';
import { Film, Instagram, Twitter, Facebook, Youtube } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Footer: React.FC = () => {
  const { t } = useLanguage();
  
  return (
    <footer className="bg-navy-900 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <Link to="/" className="flex items-center space-x-2 mb-4">
              <Film className="h-8 w-8 text-gold-500" />
              <span className="text-xl font-bold">{t('app.name')}</span>
            </Link>
            <p className="text-gray-400 mb-4">
              منصة رائدة تجمع بين التدريب والتوظيف وإدارة العقود في صناعة الأفلام السعودية
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">روابط سريعة</h3>
            <ul className="space-y-2">
              <li><Link to="/academy" className="text-gray-400 hover:text-gold-400 transition">الأكاديمية</Link></li>
              <li><Link to="/talent" className="text-gray-400 hover:text-gold-400 transition">المواهب</Link></li>
              <li><Link to="/jobs" className="text-gray-400 hover:text-gold-400 transition">الوظائف</Link></li>
              <li><Link to="/community" className="text-gray-400 hover:text-gold-400 transition">المجتمع</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">الدعم والمساعدة</h3>
            <ul className="space-y-2">
              <li><Link to="#" className="text-gray-400 hover:text-gold-400 transition">الأسئلة الشائعة</Link></li>
              <li><Link to="#" className="text-gray-400 hover:text-gold-400 transition">اتصل بنا</Link></li>
              <li><Link to="#" className="text-gray-400 hover:text-gold-400 transition">سياسة الخصوصية</Link></li>
              <li><Link to="#" className="text-gray-400 hover:text-gold-400 transition">شروط الاستخدام</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">اشترك في نشرتنا</h3>
            <p className="text-gray-400 mb-4">احصل على آخر أخبار الصناعة وفرص العمل</p>
            <form className="flex">
              <input
                type="email"
                placeholder="بريدك الإلكتروني"
                className="bg-navy-800 text-white px-4 py-2 rounded-l-md focus:outline-none focus:ring-1 focus:ring-gold-500 w-full"
              />
              <button
                type="submit"
                className="bg-gold-500 text-navy-900 px-4 py-2 rounded-r-md hover:bg-gold-400 transition"
              >
                اشترك
              </button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-navy-700 pt-6 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} {t('app.name')}. جميع الحقوق محفوظة</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;