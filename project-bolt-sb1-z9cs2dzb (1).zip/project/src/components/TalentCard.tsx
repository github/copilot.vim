import React from 'react';
import { Star, MapPin, Film } from 'lucide-react';

interface Talent {
  id: number;
  name: string;
  role: string;
  image: string;
  rating: number;
  projects: number;
  location: string;
}

interface TalentCardProps {
  talent: Talent;
}

const TalentCard: React.FC<TalentCardProps> = ({ talent }) => {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition duration-300 transform hover:-translate-y-1 group">
      <div className="relative overflow-hidden h-64">
        <img 
          src={talent.image} 
          alt={talent.name} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-900/80 to-transparent flex flex-col justify-end p-6">
          <h3 className="text-xl font-bold text-white mb-1">{talent.name}</h3>
          <p className="text-white/90 text-sm mb-2">{talent.role}</p>
          <div className="flex items-center text-white/80 text-sm mb-1">
            <MapPin className="h-3.5 w-3.5 mr-1" />
            {talent.location}
          </div>
        </div>
      </div>
      <div className="p-6">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <Star className="h-4 w-4 text-amber-400 fill-current" />
            <span className="ml-1 text-gray-700">{talent.rating.toFixed(1)}</span>
          </div>
          <div className="flex items-center">
            <Film className="h-4 w-4 text-gray-400 mr-1" />
            <span className="text-gray-600 text-sm">{talent.projects} مشروع</span>
          </div>
        </div>
        <button className="w-full bg-navy-800 text-white py-2 rounded-lg hover:bg-navy-700 transition">
          عرض الملف الشخصي
        </button>
      </div>
    </div>
  );
};

export default TalentCard;