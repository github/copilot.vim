import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Film, Menu, X, Globe } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { language, setLanguage, t } = useLanguage();
  const location = useLocation();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const toggleLanguage = () => {
    setLanguage(language === 'ar' ? 'en' : 'ar');
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-navy-900 text-white sticky top-0 z-50 shadow-lg transition-all duration-300">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2" aria-label="CineTalent">
            <Film className="h-8 w-8 text-gold-500" />
            <span className="text-xl font-bold tracking-wider">{t('app.name')}</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-8 items-center">
            <Link to="/" className={`hover:text-gold-400 transition ${isActive('/') ? 'text-gold-500' : ''}`}>
              {t('nav.home')}
            </Link>
            <Link to="/academy" className={`hover:text-gold-400 transition ${isActive('/academy') ? 'text-gold-500' : ''}`}>
              {t('nav.academy')}
            </Link>
            <Link to="/talent" className={`hover:text-gold-400 transition ${isActive('/talent') ? 'text-gold-500' : ''}`}>
              {t('nav.talent')}
            </Link>
            <Link to="/jobs" className={`hover:text-gold-400 transition ${isActive('/jobs') ? 'text-gold-500' : ''}`}>
              {t('nav.jobs')}
            </Link>
            <Link to="/community" className={`hover:text-gold-400 transition ${isActive('/community') ? 'text-gold-500' : ''}`}>
              {t('nav.community')}
            </Link>
          </div>

          <div className="hidden md:flex items-center space-x-4">
            <button 
              onClick={toggleLanguage}
              className="flex items-center space-x-1 text-white/80 hover:text-white transition-colors"
            >
              <Globe className="h-5 w-5" />
              <span>{language.toUpperCase()}</span>
            </button>
            <Link to="/login" className="px-4 py-2 rounded-md hover:bg-navy-700 transition">
              {t('nav.login')}
            </Link>
            <Link 
              to="/register" 
              className="px-4 py-2 bg-gold-500 text-navy-900 rounded-md hover:bg-gold-400 transition font-medium"
            >
              {t('nav.register')}
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-white focus:outline-none"
            onClick={toggleMenu}
            aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden pt-4 pb-3 space-y-3 transition-all duration-300 ease-in-out">
            <Link 
              to="/" 
              className={`block py-2 px-4 ${isActive('/') ? 'bg-navy-800 text-gold-500' : 'hover:bg-navy-800'} rounded transition`}
              onClick={toggleMenu}
            >
              {t('nav.home')}
            </Link>
            <Link 
              to="/academy" 
              className={`block py-2 px-4 ${isActive('/academy') ? 'bg-navy-800 text-gold-500' : 'hover:bg-navy-800'} rounded transition`}
              onClick={toggleMenu}
            >
              {t('nav.academy')}
            </Link>
            <Link 
              to="/talent" 
              className={`block py-2 px-4 ${isActive('/talent') ? 'bg-navy-800 text-gold-500' : 'hover:bg-navy-800'} rounded transition`}
              onClick={toggleMenu}
            >
              {t('nav.talent')}
            </Link>
            <Link 
              to="/jobs" 
              className={`block py-2 px-4 ${isActive('/jobs') ? 'bg-navy-800 text-gold-500' : 'hover:bg-navy-800'} rounded transition`}
              onClick={toggleMenu}
            >
              {t('nav.jobs')}
            </Link>
            <Link 
              to="/community" 
              className={`block py-2 px-4 ${isActive('/community') ? 'bg-navy-800 text-gold-500' : 'hover:bg-navy-800'} rounded transition`}
              onClick={toggleMenu}
            >
              {t('nav.community')}
            </Link>
            <div className="pt-2 border-t border-navy-700 flex justify-between items-center">
              <button 
                onClick={toggleLanguage}
                className="flex items-center space-x-1 py-2 px-4 text-white/80 hover:text-white"
              >
                <Globe className="h-5 w-5" />
                <span>{language === 'ar' ? 'العربية' : 'English'}</span>
              </button>
              <div className="space-x-2">
                <Link 
                  to="/login" 
                  className="py-2 px-3 rounded-md hover:bg-navy-700 transition inline-block"
                  onClick={toggleMenu}
                >
                  {t('nav.login')}
                </Link>
                <Link 
                  to="/register" 
                  className="py-2 px-3 bg-gold-500 text-navy-900 rounded-md hover:bg-gold-400 transition font-medium inline-block"
                  onClick={toggleMenu}
                >
                  {t('nav.register')}
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;