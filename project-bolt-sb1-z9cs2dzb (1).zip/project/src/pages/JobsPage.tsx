import React from 'react';
import JobCard from '../components/JobCard';

const JobsPage: React.FC = () => {
  // Sample job listings data
  const jobs = [
    {
      id: 1,
      title: 'Frontend Developer',
      company: 'Tech Solutions Inc.',
      location: 'Remote',
      type: 'Full-time',
      description: 'We are looking for an experienced Frontend Developer proficient in React and TypeScript.',
      salary: '$80,000 - $120,000',
      postedDate: '2023-06-15'
    },
    {
      id: 2,
      title: 'Backend Engineer',
      company: 'Data Systems Ltd.',
      location: 'New York, NY',
      type: 'Full-time',
      description: 'Seeking a Backend Engineer with experience in Node.js and database management.',
      salary: '$90,000 - $130,000',
      postedDate: '2023-06-10'
    },
    {
      id: 3,
      title: 'UX/UI Designer',
      company: 'Creative Minds',
      location: 'San Francisco, CA',
      type: 'Contract',
      description: 'Looking for a talented UX/UI Designer to join our creative team.',
      salary: '$70 - $90 per hour',
      postedDate: '2023-06-05'
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-center mb-8">Job Opportunities</h1>
      
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Find Your Next Opportunity</h2>
          <div className="flex flex-col md:flex-row gap-4">
            <input 
              type="text" 
              placeholder="Search by keyword" 
              className="flex-1 p-2 border rounded-md"
            />
            <select className="p-2 border rounded-md">
              <option value="">All Locations</option>
              <option value="remote">Remote</option>
              <option value="new-york">New York</option>
              <option value="san-francisco">San Francisco</option>
            </select>
            <button className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700">
              Search
            </button>
          </div>
        </div>
        
        <div className="space-y-6">
          {jobs.map(job => (
            <JobCard key={job.id} job={job} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default JobsPage;