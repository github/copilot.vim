import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';

const CommunityPage: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-navy-900 mb-4">{t('community.title')}</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {t('community.subtitle')}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Content will be added here */}
          <div className="bg-white p-8 rounded-xl shadow-lg">
            <h2 className="text-2xl font-bold mb-4">قريباً</h2>
            <p className="text-gray-600">
              نعمل على تطوير هذا القسم. ترقبوا المزيد من المميزات قريباً!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommunityPage;