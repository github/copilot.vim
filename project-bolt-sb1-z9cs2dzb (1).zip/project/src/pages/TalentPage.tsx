import React from 'react';
import TalentCard from '../components/TalentCard';

const TalentPage: React.FC = () => {
  // Sample talent data - in a real application, this would come from an API
  const talents = [
    {
      id: 1,
      name: 'Jane Smith',
      title: 'Frontend Developer',
      skills: ['React', 'TypeScript', 'Tailwind CSS'],
      availability: 'Full-time',
      imageUrl: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=800'
    },
    {
      id: 2,
      name: 'John Doe',
      title: 'Backend Developer',
      skills: ['Node.js', 'Python', 'MongoDB'],
      availability: 'Contract',
      imageUrl: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=800'
    },
    {
      id: 3,
      name: 'Emily Chen',
      title: 'Full Stack Developer',
      skills: ['React', 'Node.js', 'PostgreSQL'],
      availability: 'Part-time',
      imageUrl: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=800'
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Tech Talent Marketplace</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Connect with skilled professionals ready to join your team or project.
        </p>
      </div>

      <div className="flex flex-wrap justify-center gap-8 mb-12">
        <div className="w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">Filter Talent</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-gray-700 mb-2">Skills</label>
                <select className="w-full p-2 border rounded">
                  <option>All Skills</option>
                  <option>React</option>
                  <option>Node.js</option>
                  <option>TypeScript</option>
                  <option>Python</option>
                </select>
              </div>
              <div>
                <label className="block text-gray-700 mb-2">Availability</label>
                <select className="w-full p-2 border rounded">
                  <option>Any Availability</option>
                  <option>Full-time</option>
                  <option>Part-time</option>
                  <option>Contract</option>
                </select>
              </div>
              <button className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition">
                Apply Filters
              </button>
            </div>
          </div>
        </div>

        <div className="w-full md:w-1/2 lg:w-2/3 xl:w-3/4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {talents.map(talent => (
              <TalentCard key={talent.id} talent={talent} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TalentPage;