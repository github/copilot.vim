import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';

const ProfilePage: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <div className="bg-white rounded-xl shadow-lg p-8">
            <h1 className="text-3xl font-bold text-navy-900 mb-6">الملف الشخصي</h1>
            <p className="text-gray-600 mb-4">
              يرجى تسجيل الدخول لعرض ملفك الشخصي
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;