import React from 'react';
import { Search, Filter, BookOpen } from 'lucide-react';
import CourseCard from '../components/CourseCard';
import { useLanguage } from '../contexts/LanguageContext';

const AcademyPage: React.FC = () => {
  const { t } = useLanguage();

  // Sample courses data
  const courses = [
    {
      id: 1,
      title: 'أساسيات الإخراج السينمائي',
      instructor: 'محمد الأحمد',
      image: 'https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg',
      price: 750,
      duration: '8 أسابيع',
      level: 'متوسط',
      rating: 4.8,
    },
    {
      id: 2,
      title: 'فن التصوير السينمائي',
      instructor: 'سارة المهندس',
      image: 'https://images.pexels.com/photos/3062541/pexels-photo-3062541.jpeg',
      price: 850,
      duration: '6 أسابيع',
      level: 'متقدم',
      rating: 4.9,
    },
    {
      id: 3,
      title: 'المونتاج الاحترافي',
      instructor: 'عبدالله الخالدي',
      image: 'https://images.pexels.com/photos/1409999/pexels-photo-1409999.jpeg',
      price: 650,
      duration: '5 أسابيع',
      level: 'مبتدئ',
      rating: 4.7,
    },
    {
      id: 4,
      title: 'كتابة السيناريو للأفلام',
      instructor: 'فاطمة الزهراني',
      image: 'https://images.pexels.com/photos/3760529/pexels-photo-3760529.jpeg',
      price: 600,
      duration: '4 أسابيع',
      level: 'مبتدئ',
      rating: 4.6,
    },
    {
      id: 5,
      title: 'إنتاج الأفلام الوثائقية',
      instructor: 'أحمد العمري',
      image: 'https://images.pexels.com/photos/2873486/pexels-photo-2873486.jpeg',
      price: 950,
      duration: '10 أسابيع',
      level: 'متقدم',
      rating: 4.9,
    },
    {
      id: 6,
      title: 'التمثيل أمام الكاميرا',
      instructor: 'نورة القحطاني',
      image: 'https://images.pexels.com/photos/3379943/pexels-photo-3379943.jpeg',
      price: 700,
      duration: '8 أسابيع',
      level: 'متوسط',
      rating: 4.8,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold text-navy-900 mb-4">{t('academy.title')}</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {t('academy.subtitle')}
          </p>
        </div>
        
        {/* Search and Filters */}
        <div className="bg-white p-6 rounded-xl shadow-md mb-10">
          <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="ابحث عن دورة..."
                className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold-500"
              />
            </div>
            <div className="flex space-x-3">
              <select className="px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold-500 bg-white">
                <option value="">جميع المستويات</option>
                <option value="beginner">مبتدئ</option>
                <option value="intermediate">متوسط</option>
                <option value="advanced">متقدم</option>
              </select>
              <select className="px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold-500 bg-white">
                <option value="">جميع التخصصات</option>
                <option value="directing">إخراج</option>
                <option value="photography">تصوير</option>
                <option value="editing">مونتاج</option>
                <option value="writing">كتابة</option>
                <option value="acting">تمثيل</option>
              </select>
              <button className="bg-navy-800 text-white px-4 py-3 rounded-lg hover:bg-navy-700 transition flex items-center">
                <Filter className="h-5 w-5 mr-2" />
                <span>تصفية</span>
              </button>
            </div>
          </div>
        </div>
        
        {/* Categories */}
        <div className="flex overflow-x-auto pb-4 mb-8 gap-3 no-scrollbar">
          <button className="flex-shrink-0 bg-gold-500 text-navy-900 px-6 py-2 rounded-full font-medium">
            جميع الدورات
          </button>
          <button className="flex-shrink-0 bg-white text-navy-700 hover:bg-navy-50 px-6 py-2 rounded-full font-medium transition">
            الإخراج
          </button>
          <button className="flex-shrink-0 bg-white text-navy-700 hover:bg-navy-50 px-6 py-2 rounded-full font-medium transition">
            التصوير
          </button>
          <button className="flex-shrink-0 bg-white text-navy-700 hover:bg-navy-50 px-6 py-2 rounded-full font-medium transition">
            المونتاج
          </button>
          <button className="flex-shrink-0 bg-white text-navy-700 hover:bg-navy-50 px-6 py-2 rounded-full font-medium transition">
            كتابة السيناريو
          </button>
          <button className="flex-shrink-0 bg-white text-navy-700 hover:bg-navy-50 px-6 py-2 rounded-full font-medium transition">
            الإنتاج
          </button>
          <button className="flex-shrink-0 bg-white text-navy-700 hover:bg-navy-50 px-6 py-2 rounded-full font-medium transition">
            التمثيل
          </button>
        </div>
        
        {/* Featured Courses */}
        <div className="mb-16">
          <div className="flex items-center mb-8">
            <BookOpen className="h-6 w-6 text-gold-500 mr-2" />
            <h2 className="text-2xl font-bold text-navy-900">الدورات المميزة</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courses.slice(0, 3).map(course => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        </div>
        
        {/* All Courses */}
        <div>
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-bold text-navy-900">جميع الدورات</h2>
            <div className="flex items-center">
              <span className="mr-2 text-gray-600">ترتيب حسب:</span>
              <select className="px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold-500 bg-white">
                <option value="popular">الأكثر شعبية</option>
                <option value="recent">الأحدث</option>
                <option value="price-low">السعر: من الأقل إلى الأعلى</option>
                <option value="price-high">السعر: من الأعلى إلى الأقل</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courses.map(course => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AcademyPage;