import React from 'react';
import { Link } from 'react-router-dom';
import { Flame, Users, Briefcase, GraduationCap } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import FeatureCard from '../components/FeatureCard';
import CourseCard from '../components/CourseCard';
import TalentCard from '../components/TalentCard';
import JobCard from '../components/JobCard';

const HomePage: React.FC = () => {
  const { t } = useLanguage();

  // Sample data for featured sections
  const featuredCourses = [
    {
      id: 1,
      title: 'أساسيات الإخراج السينمائي',
      instructor: 'محمد الأحمد',
      image: 'https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg',
      price: 750,
      duration: '8 أسابيع',
      level: 'متوسط',
      rating: 4.8,
    },
    {
      id: 2,
      title: 'فن التصوير السينمائي',
      instructor: 'سارة المهندس',
      image: 'https://images.pexels.com/photos/3062541/pexels-photo-3062541.jpeg',
      price: 850,
      duration: '6 أسابيع',
      level: 'متقدم',
      rating: 4.9,
    },
    {
      id: 3,
      title: 'المونتاج الاحترافي',
      instructor: 'عبدالله الخالدي',
      image: 'https://images.pexels.com/photos/1409999/pexels-photo-1409999.jpeg',
      price: 650,
      duration: '5 أسابيع',
      level: 'مبتدئ',
      rating: 4.7,
    }
  ];

  const featuredTalents = [
    {
      id: 1,
      name: 'فهد العتيبي',
      role: 'مخرج',
      image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg',
      rating: 4.9,
      projects: 18,
      location: 'الرياض',
    },
    {
      id: 2,
      name: 'نورة الغامدي',
      role: 'مصورة سينمائية',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
      rating: 4.8,
      projects: 12,
      location: 'جدة',
    },
    {
      id: 3,
      name: 'خالد السعيد',
      role: 'مونتير',
      image: 'https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg',
      rating: 4.7,
      projects: 25,
      location: 'الدمام',
    }
  ];

  const featuredJobs = [
    {
      id: 1,
      title: 'مخرج لفيلم قصير',
      company: 'رؤية للإنتاج',
      location: 'الرياض',
      type: 'دوام كامل',
      salary: '15,000 - 20,000 ريال',
      posted: 'منذ 2 أيام',
    },
    {
      id: 2,
      title: 'مصور سينمائي',
      company: 'ألف ليلة للإنتاج الفني',
      location: 'جدة',
      type: 'مشروع',
      salary: '8,000 - 12,000 ريال',
      posted: 'منذ 5 أيام',
    },
    {
      id: 3,
      title: 'كاتب سيناريو',
      company: 'شركة المستقبل للإنتاج',
      location: 'عن بعد',
      type: 'تعاقد',
      salary: '10,000 - 15,000 ريال',
      posted: 'اليوم',
    }
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center text-white overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-r from-navy-900/90 to-navy-800/90"></div>
          <video 
            className="w-full h-full object-cover" 
            autoPlay 
            muted 
            loop
            poster="https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg"
          >
            <source src="https://player.vimeo.com/external/435674703.sd.mp4?s=01ad1ba21dc72c1d34728e1b43ef174fd3c0b74e&profile_id=165&oauth2_token_id=57447761" type="video/mp4" />
          </video>
        </div>
        
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight tracking-tight">
            {t('hero.title')}
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto text-white/90">
            {t('hero.subtitle')}
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link 
              to="/register" 
              className="bg-gold-500 text-navy-900 px-8 py-3 rounded-lg font-medium text-lg hover:bg-gold-400 transition transform hover:scale-105 shadow-lg"
            >
              {t('hero.cta')}
            </Link>
            <Link 
              to="/academy" 
              className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg font-medium text-lg hover:bg-white/10 transition transform hover:scale-105"
            >
              استكشف الدورات
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-navy-900">لماذا سينيتالنت؟</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              منصة متكاملة تجمع بين التعليم والتوظيف وإدارة العقود في صناعة الأفلام السعودية
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard 
              icon={<GraduationCap className="h-10 w-10 text-gold-500" />}
              title="الأكاديمية"
              description="دورات احترافية في مختلف مجالات صناعة الأفلام مقدمة من خبراء الصناعة"
            />
            <FeatureCard 
              icon={<Users className="h-10 w-10 text-crimson-500" />}
              title="المواهب"
              description="منصة لعرض أعمالك ومهاراتك والتواصل مع صناع الأفلام والمنتجين"
            />
            <FeatureCard 
              icon={<Briefcase className="h-10 w-10 text-teal-500" />}
              title="الوظائف"
              description="فرص عمل متنوعة في مجال صناعة الأفلام مع نظام ذكي لمطابقة المهارات"
            />
            <FeatureCard 
              icon={<Flame className="h-10 w-10 text-amber-500" />}
              title="العقود الآمنة"
              description="منظومة متكاملة لإدارة العقود والمدفوعات بطريقة آمنة وشفافة"
            />
          </div>
        </div>
      </section>

      {/* Academy Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-2 text-navy-900">{t('academy.title')}</h2>
              <p className="text-xl text-gray-600">{t('academy.subtitle')}</p>
            </div>
            <Link 
              to="/academy" 
              className="mt-4 md:mt-0 text-gold-600 hover:text-gold-500 font-medium flex items-center transition"
            >
              عرض جميع الدورات
              <span className="ml-2">&#8594;</span>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredCourses.map(course => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        </div>
      </section>

      {/* Talent Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-2 text-navy-900">{t('talent.title')}</h2>
              <p className="text-xl text-gray-600">{t('talent.subtitle')}</p>
            </div>
            <Link 
              to="/talent" 
              className="mt-4 md:mt-0 text-gold-600 hover:text-gold-500 font-medium flex items-center transition"
            >
              عرض جميع المواهب
              <span className="ml-2">&#8594;</span>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredTalents.map(talent => (
              <TalentCard key={talent.id} talent={talent} />
            ))}
          </div>
        </div>
      </section>

      {/* Jobs Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-2 text-navy-900">{t('jobs.title')}</h2>
              <p className="text-xl text-gray-600">{t('jobs.subtitle')}</p>
            </div>
            <Link 
              to="/jobs" 
              className="mt-4 md:mt-0 text-gold-600 hover:text-gold-500 font-medium flex items-center transition"
            >
              عرض جميع الوظائف
              <span className="ml-2">&#8594;</span>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {featuredJobs.map(job => (
              <JobCard key={job.id} job={job} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-navy-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">انضم إلى مجتمع صناع الأفلام السعوديين</h2>
          <p className="text-xl text-white/80 mb-8 max-w-3xl mx-auto">
            سواء كنت مبتدئاً أو محترفاً، سينيتالنت هي بوابتك لعالم صناعة الأفلام. تعلم، اعمل، تواصل وابدع مع أفضل المواهب السعودية.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link 
              to="/register" 
              className="bg-gold-500 text-navy-900 px-8 py-3 rounded-lg font-medium text-lg hover:bg-gold-400 transition transform hover:scale-105 shadow-lg"
            >
              أنشئ حسابك الآن
            </Link>
            <Link 
              to="/jobs" 
              className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-lg font-medium text-lg hover:bg-white/10 transition transform hover:scale-105"
            >
              استكشف الفرص
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;