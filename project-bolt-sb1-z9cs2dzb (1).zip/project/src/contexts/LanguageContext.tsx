import React, { createContext, useState, useContext, ReactNode } from 'react';

type Language = 'ar' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

const translations = {
  ar: {
    'app.name': 'سينيتالنت',
    'nav.home': 'الرئيسية',
    'nav.academy': 'الأكاديمية',
    'nav.talent': 'المواهب',
    'nav.jobs': 'الوظائف',
    'nav.community': 'المجتمع',
    'nav.profile': 'الملف الشخصي',
    'nav.login': 'تسجيل الدخول',
    'nav.register': 'إنشاء حساب',
    'hero.title': 'منصة المواهب السينمائية الأولى في المملكة',
    'hero.subtitle': 'تعلم. اعمل. تواصل. ابدع.',
    'hero.cta': 'انضم إلينا',
    'academy.title': 'أكاديمية سينيتالنت',
    'academy.subtitle': 'تعلم من أفضل المختصين في صناعة الأفلام',
    'talent.title': 'استكشف المواهب',
    'talent.subtitle': 'تواصل مع أفضل المواهب في المجال',
    'jobs.title': 'فرص العمل',
    'jobs.subtitle': 'اعثر على وظيفتك المثالية في عالم السينما',
    'community.title': 'مجتمع المبدعين',
    'community.subtitle': 'تواصل وتعاون مع صناع الأفلام',
  },
  en: {
    'app.name': 'CineTalent',
    'nav.home': 'Home',
    'nav.academy': 'Academy',
    'nav.talent': 'Talent',
    'nav.jobs': 'Jobs',
    'nav.community': 'Community',
    'nav.profile': 'Profile',
    'nav.login': 'Login',
    'nav.register': 'Register',
    'hero.title': 'Saudi Arabia\'s Premier Film Industry Platform',
    'hero.subtitle': 'Learn. Work. Connect. Create.',
    'hero.cta': 'Join Now',
    'academy.title': 'CineTalent Academy',
    'academy.subtitle': 'Learn from the best in the film industry',
    'talent.title': 'Explore Talent',
    'talent.subtitle': 'Connect with the best talent in the field',
    'jobs.title': 'Job Opportunities',
    'jobs.subtitle': 'Find your perfect job in the film world',
    'community.title': 'Creative Community',
    'community.subtitle': 'Connect and collaborate with filmmakers',
  }
};

const LanguageContext = createContext<LanguageContextType>({
  language: 'ar',
  setLanguage: () => {},
  t: (key: string) => key,
});

export const useLanguage = () => useContext(LanguageContext);

export const LanguageProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('ar');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations[typeof language]] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};